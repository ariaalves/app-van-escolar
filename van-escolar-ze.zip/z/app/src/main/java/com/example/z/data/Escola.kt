package com.example.z.data

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.IgnoredOnParcel
import kotlinx.parcelize.Parcelize

@Entity(tableName = "escolas")
@Parcelize
data class Escola(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nome: String,
    val cep: String,
    val logradouro: String,
    val bairro: String,
    val numero: String
) : Parcelable {
    @IgnoredOnParcel
    val enderecoCompleto: String
        get() = if (logradouro.isNotEmpty()) "$logradouro, $numero - $bairro" else ""
}