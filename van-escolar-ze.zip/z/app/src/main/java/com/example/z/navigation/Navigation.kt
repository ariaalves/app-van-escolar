//package com.example.z.navigation
//
//import androidx.compose.runtime.Composable
//import androidx.navigation.compose.NavHost
//import androidx.navigation.compose.composable
//import androidx.navigation.compose.rememberNavController
//import com.example.z.ui.screens.AreaDoResponsavelScreen
//import com.example.z.ui.screens.CadastroDeAlunoScreen
//import com.example.z.ui.screens.CadastroDeResponsavelScreen
//
//@Composable
//fun Navigation() {
//    val navController = rememberNavController()
//    NavHost(navController = navController, startDestination = "cadastro_aluno") {
//        composable("cadastro_aluno") {
//            CadastroDeAlunoScreen(navController = navController)
//        }
//        composable("area_responsavel") {
//            AreaDoResponsavelScreen(navController = navController, responsaveis = emptyList()) // TODO: Passar a lista de responsáveis
//        }
//        composable("cadastro_responsavel") {
//            CadastroDeResponsavelScreen(navController = navController)
//        }
//    }
//}
package com.example.z.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.z.ui.screens.AreaDoResponsavelScreen
import com.example.z.ui.screens.CadastroDeAlunoScreen // Verifique se esta tela ainda existe ou se mudou para AlunosCreateScreen
import com.example.z.ui.screens.CadastroDeResponsavelScreen

@Composable
fun Navigation() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "cadastro_aluno") {

        // Rota de Cadastro de Aluno (Supondo que seja a AlunosCreateScreen ou similar)
        composable("cadastro_aluno") {
            // Se você estiver usando a tela antiga 'CadastroDeAlunoScreen':
            // CadastroDeAlunoScreen(navController = navController)

            // Se já migrou para a nova estrutura vista na MainActivity, use algo assim:
            /*
            AlunosCreateScreen(
                student = null,
                onNavigateBack = { navController.popBackStack() },
                onSave = { /* lógica de salvar aqui ou passar ViewModel */ }
            )
            */
        }

        // Rota da Área do Responsável
        composable("area_responsavel") {
            AreaDoResponsavelScreen(
                navController = navController,
                responsaveis = emptyList(), // Aqui você precisaria passar a lista real (ex: vinda de um ViewModel)
                onNavigateToCreate = { navController.navigate("cadastro_responsavel") },
                onEditResponsavel = { /* lógica de edição */ },
                onDeleteResponsavel = { /* lógica de deletar */ }
            )
        }

        // Rota de Cadastro de Responsável
        composable("cadastro_responsavel") {
            CadastroDeResponsavelScreen(
                navController = navController,
                responsavel = null, // null pois é um novo cadastro
                onSave = { novoResponsavel ->
                    // Aqui você precisa chamar seu ViewModel para salvar
                    navController.popBackStack()
                }
            )
        }
    }
}
