package com.example.z.data.dao

import androidx.room.*
import com.example.z.data.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SchoolDao {
    // --- Aluno ---
    @Query("SELECT * FROM alunos")
    fun getAllAlunos(): Flow<List<Aluno>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAluno(aluno: Aluno)

    @Delete
    suspend fun deleteAluno(aluno: Aluno)

    // --- Escola ---
    @Query("SELECT * FROM escolas")
    fun getAllEscolas(): Flow<List<Escola>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEscola(escola: Escola)

    @Delete
    suspend fun deleteEscola(escola: Escola)

    // --- Turma ---
    @Query("SELECT * FROM turmas")
    fun getAllTurmas(): Flow<List<Turma>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTurma(turma: Turma)

    @Delete
    suspend fun deleteTurma(turma: Turma)

    // --- Responsavel ---
    @Query("SELECT * FROM responsaveis")
    fun getAllResponsaveis(): Flow<List<Responsavel>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResponsavel(responsavel: Responsavel)

    @Delete
    suspend fun deleteResponsavel(responsavel: Responsavel)

    // --- MembroEquipe ---
    @Query("SELECT * FROM membros_equipe")
    fun getAllMembrosEquipe(): Flow<List<MembroEquipe>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMembroEquipe(membro: MembroEquipe)

    @Delete
    suspend fun deleteMembroEquipe(membro: MembroEquipe)
}