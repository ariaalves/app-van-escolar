package com.example.z.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.z.data.Escola
import com.example.z.data.Turma

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CadastroTurmaScreen(
    navController: NavController,
    turma: Turma? = null,
    onSave: (Turma) -> Unit
) {
    val isEditing = turma != null
    var nome by remember { mutableStateOf(turma?.nome ?: "") }
    var ano by remember { mutableStateOf(turma?.data ?: "") } // Usando 'data' como ano/série conforme modelo atual
    var turno by remember { mutableStateOf(turma?.turno ?: "") }
    var observacoes by remember { mutableStateOf(turma?.observacoes ?: "") }
    var escola by remember { mutableStateOf<Escola?>(null) }
    
    // Nota: O campo 'escola' no objeto Turma é String. 
    // Se quisermos manter a consistência, deveríamos salvar o nome da escola ou ID.
    // Aqui assumiremos que salvamos o nome por enquanto.
    var escolaNome by remember { mutableStateOf(turma?.escola ?: "") }

    val savedStateHandle = navController.currentBackStackEntry?.savedStateHandle
    val selectedEscola = savedStateHandle?.get<Escola>("selected_escola")
    
    LaunchedEffect(selectedEscola) {
        selectedEscola?.let {
            escola = it
            escolaNome = it.nome
            savedStateHandle.remove<Escola>("selected_escola")
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditing) "Editar Turma" else "Cadastro de Turmas") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        },
        bottomBar = {
            Button(
                onClick = { 
                    if (nome.isNotBlank()) {
                        val newTurma = turma?.copy(
                            nome = nome,
                            data = ano,
                            escola = escolaNome,
                            turno = turno,
                            observacoes = observacoes
                        ) ?: Turma(
                            nome = nome,
                            data = ano,
                            escola = escolaNome,
                            turno = turno,
                            observacoes = observacoes
                        )
                        onSave(newTurma)
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Text(if (isEditing) "Salvar" else "Cadastrar Turma")
            }
        }
    ) {
        Column(modifier = Modifier.padding(it).padding(16.dp)) {
            OutlinedTextField(
                value = nome,
                onValueChange = { nome = it },
                label = { Text("Nome da Turma") },
                supportingText = { Text("Ex: Turma 101, 3º Ano A") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = ano,
                onValueChange = { ano = it },
                label = { Text("Ano / Série") },
                supportingText = { Text("Ex: 9º Ano, 3ª Série") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = turno,
                onValueChange = { turno = it },
                label = { Text("Turno") },
                supportingText = { Text("Manhã, Tarde ou Noite") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = observacoes,
                onValueChange = { observacoes = it },
                label = { Text("Observações") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))
            
            // Se tivermos uma escola selecionada (objeto) mostramos o card, senão o nome (se edição) ou botão
            if (escola != null) {
                EscolaCard(escola = escola!!, onRemove = { 
                    escola = null 
                    escolaNome = ""
                })
            } else if (escolaNome.isNotBlank()) {
                // Caso de edição onde temos o nome mas não o objeto completo carregado
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Escola: $escolaNome", style = MaterialTheme.typography.bodyLarge)
                        Button(onClick = { escolaNome = "" }) { Text("Alterar") }
                    }
                }
            } else {
                Button(onClick = { navController.navigate("area_escolas") }) {
                    Text("Adicionar Escola")
                }
            }
        }
    }
}

@Composable
fun EscolaCard(escola: Escola, onRemove: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Escola", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(escola.nome)
                    Text(escola.enderecoCompleto)
                }
                OutlinedButton(onClick = onRemove) {
                    Text("Remover")
                }
            }
        }
    }
}
