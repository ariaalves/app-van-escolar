package com.example.z.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.z.data.Aluno
import com.example.z.data.Escola
import com.example.z.data.Responsavel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CadastroDeAlunoScreen(
    navController: NavController,
    aluno: Aluno? = null,
    onSave: (Aluno) -> Unit
) {
    val isEditing = aluno != null
    var nome by remember { mutableStateOf(aluno?.nome ?: "") }
    var dataNascimento by remember { mutableStateOf(aluno?.dataNascimento ?: "") }
    var turma by remember { mutableStateOf("") } // Nota: Aluno tem turmaId, mas por enquanto estamos usando String ou sem link direto na UI simples
    var observacoes by remember { mutableStateOf(aluno?.observacoes ?: "") }
    var email by remember { mutableStateOf(aluno?.email ?: "") }
    var telefone by remember { mutableStateOf(aluno?.telefone ?: "") }
    
    var responsavel by remember { mutableStateOf<Responsavel?>(null) }
    var escola by remember { mutableStateOf<Escola?>(null) }
    var isEscolaMenuExpanded by remember { mutableStateOf(false) }

    // Lista de exemplo de escolas (Idealmente viria do Banco de Dados/ViewModel)
    val escolas = listOf(
        Escola(
            nome = "Escola Modelo", 
            cep = "00000-000", 
            logradouro = "Rua dos Exemplos", 
            bairro = "Centro", 
            numero = "123"
        ),
        Escola(
            nome = "Colégio Padrão", 
            cep = "00000-000", 
            logradouro = "Avenida dos Testes", 
            bairro = "Bairro Novo", 
            numero = "456"
        )
    )

    val savedStateHandle = navController.currentBackStackEntry?.savedStateHandle
    val selectedResponsavel = savedStateHandle?.get<Responsavel>("selected_responsavel")
    // Handle restoring/receiving objects if passed via navigation arguments wrapper (omitted for simplicity in this generic fix, relying on 'aluno' param)

    LaunchedEffect(selectedResponsavel) {
        selectedResponsavel?.let {
            responsavel = it
            savedStateHandle.remove<Responsavel>("selected_responsavel")
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditing) "Editar Aluno" else "Cadastro de Aluno") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        },
        bottomBar = {
            Button(
                onClick = { 
                    if (nome.isNotBlank()) {
                        // Usando argumentos nomeados para evitar erros de tipo com o ID (primeiro parâmetro)
                        val newAluno = aluno?.copy(
                            nome = nome,
                            email = email,
                            telefone = telefone,
                            observacoes = observacoes,
                            dataNascimento = dataNascimento
                        ) ?: Aluno(
                            nome = nome,
                            email = email,
                            telefone = telefone,
                            observacoes = observacoes,
                            dataNascimento = dataNascimento
                        )
                        onSave(newAluno)
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Text(if (isEditing) "Salvar" else "Cadastrar Aluno")
            }
        }
    ) {
        Column(modifier = Modifier.padding(it).padding(16.dp)) {
            OutlinedTextField(
                value = nome,
                onValueChange = { nome = it },
                label = { Text("Nome do aluno") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = dataNascimento,
                onValueChange = { dataNascimento = it },
                label = { Text("Data de nascimento") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = telefone,
                onValueChange = { telefone = it },
                label = { Text("Telefone") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = observacoes,
                onValueChange = { observacoes = it },
                label = { Text("Observações") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Menu de Seleção de Escola
            ExposedDropdownMenuBox(
                expanded = isEscolaMenuExpanded,
                onExpandedChange = { isEscolaMenuExpanded = !isEscolaMenuExpanded },
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = escola?.nome ?: "",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Escola") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isEscolaMenuExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = isEscolaMenuExpanded,
                    onDismissRequest = { isEscolaMenuExpanded = false },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    escolas.forEach { selEscola ->
                        DropdownMenuItem(
                            text = { Text(selEscola.nome) },
                            onClick = {
                                escola = selEscola
                                isEscolaMenuExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            val currentResponsavel = responsavel
            if (currentResponsavel == null) {
                Button(onClick = { navController.navigate("area_responsavel") }) {
                    Text("Adicionar Responsável")
                }
            } else {
                ResponsavelAlunoCard(responsavel = currentResponsavel, onRemove = { responsavel = null })
            }
        }
    }
}

@Composable
fun ResponsavelAlunoCard(responsavel: Responsavel, onRemove: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Responsável", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(responsavel.nome)
                    Text(responsavel.email)
                    Text(responsavel.telefone)
                }
                OutlinedButton(onClick = onRemove) {
                    Text("Remover")
                }
            }
        }
    }
}
