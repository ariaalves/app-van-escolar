package com.example.z.ui.screens

// Arquivo depreciado. Por favor, utilize AreaDoResponsavelScreen.kt
// Mantido vazio para evitar conflitos de compilação até que possa ser excluído.
