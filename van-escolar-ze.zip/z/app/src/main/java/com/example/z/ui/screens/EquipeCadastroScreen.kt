package com.example.z.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.z.data.MembroEquipe

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EquipeCadastroScreen(
    navController: NavController, 
    membro: MembroEquipe? = null,
    onSave: (MembroEquipe) -> Unit
) {
    val isEditing = membro != null
    var nome by remember { mutableStateOf(membro?.nome ?: "") }
    var funcao by remember { mutableStateOf(membro?.funcao ?: "") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditing) "Editar Integrante" else "Área da Equipe") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        },
        bottomBar = {
            Button(
                onClick = { 
                    // Using named arguments to avoid type mismatch with 'id' (Int)
                    val newMembro = membro?.copy(nome = nome, funcao = funcao) 
                        ?: MembroEquipe(nome = nome, funcao = funcao)
                    onSave(newMembro)
                },
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Text(if (isEditing) "Salvar" else "Cadastrar")
            }
        }
    ) {
        Column(modifier = Modifier.padding(it).padding(16.dp)) {
            if (!isEditing) {
                Text(
                    text = "Cadastro",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }
            OutlinedTextField(
                value = nome,
                onValueChange = { nome = it },
                label = { Text("Nome") },
                supportingText = { Text("Nome completo") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = funcao,
                onValueChange = { funcao = it },
                label = { Text("Função") },
                supportingText = { Text("Ex: Motorista, Monitor") },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
