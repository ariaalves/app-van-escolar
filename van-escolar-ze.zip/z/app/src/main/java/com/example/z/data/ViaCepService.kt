package com.example.z.data

import retrofit2.http.GET
import retrofit2.http.Path

interface ViaCepService {
    @GET("{cep}/json")
    suspend fun getEndereco(@Path("cep") cep: String): ViaCepResponse
}