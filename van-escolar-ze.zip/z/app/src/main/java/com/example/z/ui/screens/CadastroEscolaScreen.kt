package com.example.z.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.z.data.Escola
import com.example.z.data.RetrofitInstance
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CadastroEscolaScreen(
    navController: NavController, 
    escola: Escola? = null,
    onSave: (Escola) -> Unit
) {
    val isEditing = escola != null
    var nome by remember { mutableStateOf(escola?.nome ?: "") }
    var cep by remember { mutableStateOf(escola?.cep ?: "") }
    var logradouro by remember { mutableStateOf(escola?.logradouro ?: "") }
    var bairro by remember { mutableStateOf(escola?.bairro ?: "") }
    var numero by remember { mutableStateOf(escola?.numero ?: "") }
    
    var isLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val savedStateHandle = navController.currentBackStackEntry?.savedStateHandle
    val receivedEscola = savedStateHandle?.get<Escola>("escola")

    LaunchedEffect(receivedEscola) {
        receivedEscola?.let {
            nome = it.nome
            cep = it.cep
            logradouro = it.logradouro
            bairro = it.bairro
            numero = it.numero
            savedStateHandle.remove<Escola>("escola")
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditing || receivedEscola != null) "Editar Escola" else "Cadastro de Escola") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        },
        bottomBar = {
            Button(
                onClick = { 
                    // Usando argumentos nomeados para garantir compatibilidade com o construtor
                    val newEscola = Escola(
                        id = escola?.id ?: 0,
                        nome = nome, 
                        cep = cep, 
                        logradouro = logradouro, 
                        bairro = bairro, 
                        numero = numero
                    )
                    onSave(newEscola)
                },
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                enabled = !isLoading && nome.isNotBlank() && cep.isNotBlank() && numero.isNotBlank()
            ) {
                Text(if (isEditing || receivedEscola != null) "Salvar" else "Cadastrar")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = nome,
                onValueChange = { nome = it },
                label = { Text("Nome da escola") },
                modifier = Modifier.fillMaxWidth()
            )
            
            OutlinedTextField(
                value = cep,
                onValueChange = { newValue ->
                    if (newValue.all { char -> char.isDigit() } && newValue.length <= 8) {
                        cep = newValue
                        if (newValue.length == 8) {
                            isLoading = true
                            scope.launch {
                                try {
                                    val response = RetrofitInstance.api.getEndereco(newValue)
                                    logradouro = response.logradouro ?: ""
                                    bairro = response.bairro ?: ""
                                } catch (e: Exception) {
                                    // Opcional: tratar erro
                                } finally {
                                    isLoading = false
                                }
                            }
                        }
                    }
                },
                label = { Text("CEP") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                trailingIcon = {
                    if (isLoading) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                    }
                }
            )
            
            OutlinedTextField(
                value = logradouro,
                onValueChange = { logradouro = it },
                label = { Text("Logradouro") },
                modifier = Modifier.fillMaxWidth()
            )
            
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = bairro,
                    onValueChange = { bairro = it },
                    label = { Text("Bairro") },
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = numero,
                    onValueChange = { numero = it },
                    label = { Text("Número") },
                    modifier = Modifier.width(100.dp)
                )
            }
        }
    }
}
