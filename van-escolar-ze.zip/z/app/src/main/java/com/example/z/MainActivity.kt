package com.example.z

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.z.data.*
import com.example.z.ui.screens.*
import com.example.z.viewmodel.SchoolViewModel
import kotlinx.coroutines.launch

// --- Constants & Colors ---
val BackgroundColor = Color(0xFFFAF7FB)
val DrawerBackgroundColor = Color(0xFFF5F3F7)
val AccentColor = Color(0xFF6B4D9A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                MainAppScreen()
            }
        }
    }
}

@Composable
fun MainAppScreen() {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val viewModel: SchoolViewModel = viewModel()

    // Observing StateFlows from ViewModel
    val students by viewModel.alunos.collectAsState()
    val turmas by viewModel.turmas.collectAsState()
    val responsaveis by viewModel.responsaveis.collectAsState()
    val escolas by viewModel.escolas.collectAsState()
    val membros by viewModel.membrosEquipe.collectAsState()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerContent(
                currentRoute = currentRoute,
                onNavigate = { route ->
                    scope.launch { drawerState.close() }
                    if (currentRoute != route) {
                        navController.navigate(route) {
                            popUpTo("home") { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                }
            )
        },
        content = {
            AppNavHost(
                navController = navController,
                viewModel = viewModel,
                students = students,
                turmas = turmas,
                responsaveis = responsaveis,
                escolas = escolas,
                membros = membros,
                onOpenDrawer = { scope.launch { drawerState.open() } }
            )
        }
    )
}

@Composable
fun DrawerContent(
    currentRoute: String?,
    onNavigate: (String) -> Unit
) {
    ModalDrawerSheet(
        drawerContainerColor = DrawerBackgroundColor,
        drawerShape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp),
        modifier = Modifier.width(300.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text(
            text = "Menu Escolar",
            modifier = Modifier.padding(start = 28.dp, bottom = 12.dp),
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = Color.Gray
        )
        
        DrawerItem(Icons.Default.Home, "Home", currentRoute == "home") { onNavigate("home") }
        DrawerItem(Icons.Default.Class, "Turmas", currentRoute?.startsWith("turmas") == true) { onNavigate("turmas/list") }
        DrawerItem(Icons.Default.Group, "Equipe", currentRoute?.startsWith("equipe") == true) { onNavigate("equipe_home") }
        DrawerItem(Icons.Default.School, "Escolas", currentRoute?.startsWith("escolas") == true) { onNavigate("area_escolas") }
        DrawerItem(Icons.Default.Person, "Alunos", currentRoute?.startsWith("alunos") == true) { onNavigate("alunos/list") }
        DrawerItem(Icons.Default.SupervisorAccount, "Responsáveis", currentRoute?.startsWith("responsaveis") == true) { onNavigate("responsaveis_list") }
    }
}

@Composable
fun DrawerItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    badge: String? = null,
    onClick: () -> Unit
) {
    NavigationDrawerItem(
        label = {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = label,
                    modifier = Modifier.weight(1f),
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    color = if (selected) AccentColor else Color.Black
                )
                if (badge != null) {
                    Badge(containerColor = AccentColor, contentColor = Color.White) { Text(badge) }
                }
            }
        },
        icon = { Icon(icon, null, tint = if (selected) AccentColor else Color.Gray) },
        selected = selected,
        onClick = onClick,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
        colors = NavigationDrawerItemDefaults.colors(
            selectedContainerColor = Color(0xFFE8DEF8).copy(alpha = 0.5f),
            unselectedContainerColor = Color.Transparent
        ),
        shape = RoundedCornerShape(8.dp)
    )
}

@Composable
fun AppNavHost(
    navController: NavController,
    viewModel: SchoolViewModel,
    students: List<Aluno>,
    turmas: List<Turma>,
    responsaveis: List<Responsavel>,
    escolas: List<Escola>,
    membros: List<MembroEquipe>,
    onOpenDrawer: () -> Unit
) {
    NavHost(navController = navController as androidx.navigation.NavHostController, startDestination = "home") {
        composable("home") {
            HomeScreen(onOpenDrawer = onOpenDrawer)
        }
        
        composable("alunos/list") {
            AlunosListScreen(
                students = students,
                onOpenDrawer = onOpenDrawer,
                onNavigateToCreate = { 
                    navController.currentBackStackEntry?.savedStateHandle?.remove<Aluno>("student")
                    navController.navigate("alunos/create") 
                },
                onStudentClick = { student ->
                    navController.currentBackStackEntry?.savedStateHandle?.set("student", student)
                    navController.navigate("alunos/create")
                },
                onDeleteStudent = { student -> viewModel.deleteAluno(student) }
            )
        }
        composable("alunos/create") {
            val student = navController.previousBackStackEntry?.savedStateHandle?.get<Aluno>("student")
            AlunosCreateScreen(
                student = student,
                onNavigateBack = { navController.popBackStack() },
                onSave = { newStudent ->
                    viewModel.saveAluno(newStudent)
                    navController.popBackStack()
                }
            )
        }

        composable("turmas/list") {
            TurmasListScreen(
                turmas = turmas,
                onOpenDrawer = onOpenDrawer,
                onNavigateToCreate = { 
                    navController.currentBackStackEntry?.savedStateHandle?.remove<Turma>("turma")
                    navController.navigate("turmas/create") 
                },
                onTurmaClick = { turma ->
                    navController.currentBackStackEntry?.savedStateHandle?.set("turma", turma)
                    navController.navigate("turmas/create")
                },
                onDeleteTurma = { turma -> viewModel.deleteTurma(turma) }
            )
        }
        composable("turmas/create") {
            val turma = navController.previousBackStackEntry?.savedStateHandle?.get<Turma>("turma")
            TurmasCreateScreen(
                turma = turma,
                onNavigateBack = { navController.popBackStack() },
                onSave = { newTurma ->
                    viewModel.saveTurma(newTurma)
                    navController.popBackStack()
                }
            )
        }

        composable("area_escolas") { 
            AreaDasEscolasScreen(navController, escolas, 
                onNavigateToCreate = {
                    navController.currentBackStackEntry?.savedStateHandle?.remove<Escola>("escola")
                    navController.navigate("cadastro_escola")
                },
                onEditEscola = {
                    navController.currentBackStackEntry?.savedStateHandle?.set("escola", it)
                    navController.navigate("cadastro_escola")
                },
                onDeleteEscola = { viewModel.deleteEscola(it) }
            )
        }
        composable("cadastro_escola") {
            val escola = navController.previousBackStackEntry?.savedStateHandle?.get<Escola>("escola")
            CadastroEscolaScreen(
                navController = navController, 
                escola = escola,
                onSave = { newEscola ->
                    viewModel.saveEscola(newEscola)
                    navController.popBackStack()
                }
            )
        }

        // Rotas da Equipe
        composable("equipe_home") { 
            EquipeHomeScreen(navController, membros, 
                onNavigateToCreate = {
                    navController.currentBackStackEntry?.savedStateHandle?.remove<MembroEquipe>("membro")
                    navController.navigate("equipe_cadastro")
                },
                onEditMembro = {
                    navController.currentBackStackEntry?.savedStateHandle?.set("membro", it)
                    navController.navigate("equipe_cadastro")
                },
                onDeleteMembro = { viewModel.deleteMembroEquipe(it) }
            )
        }
        composable("equipe_cadastro") {
            val membro = navController.previousBackStackEntry?.savedStateHandle?.get<MembroEquipe>("membro")
            EquipeCadastroScreen(
                navController = navController, 
                membro = membro,
                onSave = { newMembro ->
                    viewModel.saveMembroEquipe(newMembro)
                    navController.popBackStack()
                }
            )
        }
        
        // Rotas de Responsáveis
        composable("responsaveis_list") { 
            AreaDoResponsavelScreen(navController, responsaveis,
                onNavigateToCreate = {
                    navController.currentBackStackEntry?.savedStateHandle?.remove<Responsavel>("responsavel")
                    navController.navigate("cadastro_responsavel")
                },
                onEditResponsavel = {
                    navController.currentBackStackEntry?.savedStateHandle?.set("responsavel", it)
                    navController.navigate("cadastro_responsavel")
                },
                onDeleteResponsavel = { viewModel.deleteResponsavel(it) }
            )
        }
        composable("cadastro_responsavel") {
            val responsavel = navController.previousBackStackEntry?.savedStateHandle?.get<Responsavel>("responsavel")
            CadastroDeResponsavelScreen(
                navController = navController, 
                responsavel = responsavel,
                onSave = { newResponsavel ->
                    viewModel.saveResponsavel(newResponsavel)
                    navController.popBackStack()
                }
            )
        }
    }
}

// --- SCREENS ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onOpenDrawer: () -> Unit) {
    Scaffold(
        containerColor = BackgroundColor,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Home") },
                navigationIcon = {
                    IconButton(onClick = onOpenDrawer) { Icon(Icons.Default.Menu, "Menu") }
                },
                actions = {
                    IconButton(onClick = {}) { Icon(Icons.Default.AccountCircle, "Perfil") }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = BackgroundColor)
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier.padding(padding).fillMaxSize(), 
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.School, null, modifier = Modifier.size(64.dp), tint = Color.Gray)
                Spacer(Modifier.height(16.dp))
                Text("Bem-vindo ao Sistema Escolar", color = Color.Gray)
                Text("Selecione uma opção no menu", color = Color.Gray, fontSize = 14.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlunosListScreen(
    students: List<Aluno>,
    onOpenDrawer: () -> Unit,
    onNavigateToCreate: () -> Unit,
    onStudentClick: (Aluno) -> Unit,
    onDeleteStudent: (Aluno) -> Unit
) {
    Scaffold(
        containerColor = BackgroundColor,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Área dos Alunos", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onOpenDrawer) { Icon(Icons.Default.Menu, "Menu") }
                },
                actions = {
                    IconButton(onClick = {}) { Icon(Icons.Default.AccountCircle, "Perfil") }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = BackgroundColor)
            )
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            if (students.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Nenhum aluno cadastrado.", color = Color.Gray)
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(students) { student ->
                        StudentItem(student, onStudentClick, onDeleteStudent)
                    }
                    item { Spacer(modifier = Modifier.height(80.dp)) }
                }
            }
            
            Button(
                onClick = onNavigateToCreate,
                colors = ButtonDefaults.buttonColors(containerColor = AccentColor),
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(24.dp)
                    .height(56.dp)
            ) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(8.dp))
                Text("Cadastrar", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun StudentItem(
    student: Aluno, 
    onStudentClick: (Aluno) -> Unit,
    onDeleteStudent: (Aluno) -> Unit
) {
    var isMenuExpanded by remember { mutableStateOf(false) }
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(shape = CircleShape, color = Color(0xFFE0E0E0), modifier = Modifier.size(48.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Person, null, tint = Color.Gray)
                }
            }
            Spacer(Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = student.nome, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.Black)
                // Displaying generic guardian text since relationship is by ID now and simple join not done in UI
                Text(text = "Telefone: ${student.telefone}", fontSize = 14.sp, color = Color.Gray)
            }
            Box {
                IconButton(onClick = { isMenuExpanded = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Menu de opções")
                }
                DropdownMenu(
                    expanded = isMenuExpanded,
                    onDismissRequest = { isMenuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Editar") },
                        onClick = {
                            onStudentClick(student)
                            isMenuExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Deletar") },
                        onClick = {
                            onDeleteStudent(student)
                            isMenuExpanded = false
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlunosCreateScreen(
    student: Aluno?,
    onNavigateBack: () -> Unit,
    onSave: (Aluno) -> Unit
) {
    val isEditing = student != null
    var name by remember { mutableStateOf(student?.nome ?: "") }
    var email by remember { mutableStateOf(student?.email ?: "") }
    var phone by remember { mutableStateOf(student?.telefone ?: "") }
    var observations by remember { mutableStateOf(student?.observacoes ?: "") }

    Scaffold(
        containerColor = BackgroundColor,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(if (isEditing) "Editar Aluno" else "Novo Aluno") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) { Icon(Icons.Default.ArrowBack, "Voltar") }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = BackgroundColor)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(24.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("Nome Completo") }, modifier = Modifier.fillMaxWidth(),
                trailingIcon = { Icon(Icons.Default.Person, null) }
            )
            OutlinedTextField(
                value = email, onValueChange = { email = it },
                label = { Text("E-mail") }, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                trailingIcon = { Icon(Icons.Default.Email, null) }
            )
            OutlinedTextField(
                value = phone, onValueChange = { phone = it },
                label = { Text("Telefone") }, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                trailingIcon = { Icon(Icons.Default.Call, null) }
            )
            OutlinedTextField(
                value = observations, onValueChange = { observations = it },
                label = { Text("Observações") }, modifier = Modifier.fillMaxWidth(),
                minLines = 3, trailingIcon = { Icon(Icons.Default.Edit, null) }
            )
            Spacer(modifier = Modifier.weight(1f))
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val newStudent = student?.copy(nome = name, email = email, telefone = phone, observacoes = observations) 
                            ?: Aluno(nome = name, email = email, telefone = phone, observacoes = observations)
                        onSave(newStudent)
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentColor),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(if (isEditing) "Salvar" else "Cadastrar", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TurmasListScreen(
    turmas: List<Turma>,
    onOpenDrawer: () -> Unit,
    onNavigateToCreate: () -> Unit,
    onTurmaClick: (Turma) -> Unit,
    onDeleteTurma: (Turma) -> Unit
) {
    Scaffold(
        containerColor = BackgroundColor,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Área das Turmas", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onOpenDrawer) { Icon(Icons.Default.Menu, "Menu") }
                },
                actions = {
                    IconButton(onClick = {}) { Icon(Icons.Default.AccountCircle, "Perfil") }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = BackgroundColor)
            )
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            if (turmas.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Nenhuma turma cadastrada.", color = Color.Gray)
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(turmas) { turma ->
                        TurmaItem(turma, onTurmaClick, onDeleteTurma)
                    }
                    item { Spacer(modifier = Modifier.height(80.dp)) }
                }
            }
            
            Button(
                onClick = onNavigateToCreate,
                colors = ButtonDefaults.buttonColors(containerColor = AccentColor),
                shape = RoundedCornerShape(50),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(24.dp)
                    .height(56.dp)
            ) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(8.dp))
                Text("Cadastrar", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun TurmaItem(
    turma: Turma,
    onTurmaClick: (Turma) -> Unit,
    onDeleteTurma: (Turma) -> Unit
) {
    var isMenuExpanded by remember { mutableStateOf(false) }
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(shape = CircleShape, color = Color(0xFFE0E0E0), modifier = Modifier.size(48.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Class, null, tint = Color.Gray)
                }
            }
            Spacer(Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = turma.nome, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.Black)
                Text(text = "Data: ${turma.data}", fontSize = 14.sp, color = Color.Gray)
            }
            Box {
                IconButton(onClick = { isMenuExpanded = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Menu de opções")
                }
                DropdownMenu(
                    expanded = isMenuExpanded,
                    onDismissRequest = { isMenuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Editar") },
                        onClick = {
                            onTurmaClick(turma)
                            isMenuExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Deletar") },
                        onClick = {
                            onDeleteTurma(turma)
                            isMenuExpanded = false
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TurmasCreateScreen(
    turma: Turma?,
    onNavigateBack: () -> Unit,
    onSave: (Turma) -> Unit
) {
    val isEditing = turma != null
    var nome by remember { mutableStateOf(turma?.nome ?: "") }
    var data by remember { mutableStateOf(turma?.data ?: "") }
    var escola by remember { mutableStateOf(turma?.escola ?: "") }
    var observacoes by remember { mutableStateOf(turma?.observacoes ?: "") }

    Scaffold(
        containerColor = BackgroundColor,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(if (isEditing) "Editar Turma" else "Nova Turma") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) { Icon(Icons.Default.ArrowBack, "Voltar") }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = BackgroundColor)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(24.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = nome, onValueChange = { nome = it },
                label = { Text("Nome da Turma") }, modifier = Modifier.fillMaxWidth(),
                trailingIcon = { Icon(Icons.Default.Class, null) }
            )
            OutlinedTextField(
                value = data, onValueChange = { data = it },
                label = { Text("Data (DD/MM/AAAA)") }, modifier = Modifier.fillMaxWidth(),
                trailingIcon = { Icon(Icons.Default.CalendarToday, null) }
            )
            OutlinedTextField(
                value = escola, onValueChange = { escola = it },
                label = { Text("Escola") }, modifier = Modifier.fillMaxWidth(),
                trailingIcon = { Icon(Icons.Default.School, null) }
            )
            OutlinedTextField(
                value = observacoes, onValueChange = { observacoes = it },
                label = { Text("Observações") }, modifier = Modifier.fillMaxWidth(),
                minLines = 3, trailingIcon = { Icon(Icons.Default.Edit, null) }
            )
            Spacer(modifier = Modifier.weight(1f))
            Button(
                onClick = {
                    if (nome.isNotBlank()) {
                        val newTurma = turma?.copy(nome = nome, data = data, escola = escola, observacoes = observacoes) 
                            ?: Turma(nome = nome, data = data, escola = escola, observacoes = observacoes)
                        onSave(newTurma)
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentColor),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(if (isEditing) "Salvar" else "Cadastrar", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
