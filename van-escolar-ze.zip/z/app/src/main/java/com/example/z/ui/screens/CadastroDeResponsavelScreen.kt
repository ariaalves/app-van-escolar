package com.example.z.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.z.data.Responsavel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CadastroDeResponsavelScreen(
    navController: NavController, 
    responsavel: Responsavel? = null,
    onSave: (Responsavel) -> Unit
) {
    val isEditing = responsavel != null
    var nome by remember { mutableStateOf(responsavel?.nome ?: "") }
    var email by remember { mutableStateOf(responsavel?.email ?: "") }
    var telefone by remember { mutableStateOf(responsavel?.telefone ?: "") }

    val savedStateHandle = navController.currentBackStackEntry?.savedStateHandle
    val receivedResponsavel = savedStateHandle?.get<Responsavel>("responsavel")

    LaunchedEffect(receivedResponsavel) {
        receivedResponsavel?.let {
            nome = it.nome
            email = it.email
            telefone = it.telefone
            savedStateHandle.remove<Responsavel>("responsavel")
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditing || receivedResponsavel != null) "Editar Responsável" else "Cadastro de Responsável") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        },
        bottomBar = {
            Button(
                onClick = { 
                    val newResponsavel = responsavel?.copy(
                        nome = nome, 
                        email = email, 
                        telefone = telefone
                    ) ?: Responsavel(
                        nome = nome, 
                        email = email, 
                        telefone = telefone
                    )
                    onSave(newResponsavel)
                },
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Text(if (isEditing || receivedResponsavel != null) "Salvar" else "Cadastrar")
            }
        }
    ) {
        Column(modifier = Modifier.padding(it).padding(16.dp)) {
            OutlinedTextField(
                value = nome,
                onValueChange = { nome = it },
                label = { Text("Nome") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = telefone,
                onValueChange = { telefone = it },
                label = { Text("Telefone") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
