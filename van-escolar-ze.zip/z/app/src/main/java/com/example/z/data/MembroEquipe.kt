package com.example.z.data

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Entity(tableName = "membros_equipe")
@Parcelize
data class MembroEquipe(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nome: String,
    val funcao: String
) : Parcelable