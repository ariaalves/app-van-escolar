package com.example.z.data

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Entity(tableName = "alunos")
@Parcelize
data class Aluno(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nome: String,
    val email: String = "",
    val telefone: String = "",
    val observacoes: String = "",
    val dataNascimento: String = "",
    val responsavelId: Int? = null, // Foreign key to Responsavel
    val escolaId: Int? = null,      // Foreign key to Escola
    val turmaId: Int? = null        // Foreign key to Turma
) : Parcelable