package com.example.z.data

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Entity(tableName = "turmas")
@Parcelize
data class Turma(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nome: String,
    val data: String,
    val escola: String, // Changed from escolaId to String to match UI
    val observacoes: String = "",
    val turno: String = ""
) : Parcelable