package com.example.z.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.z.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SchoolViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = AppDatabase.getDatabase(application).schoolDao()

    val alunos: StateFlow<List<Aluno>> = dao.getAllAlunos()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val escolas: StateFlow<List<Escola>> = dao.getAllEscolas()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val turmas: StateFlow<List<Turma>> = dao.getAllTurmas()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val responsaveis: StateFlow<List<Responsavel>> = dao.getAllResponsaveis()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val membrosEquipe: StateFlow<List<MembroEquipe>> = dao.getAllMembrosEquipe()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // --- Aluno Operations ---
    fun saveAluno(aluno: Aluno) {
        viewModelScope.launch {
            dao.insertAluno(aluno)
        }
    }

    fun deleteAluno(aluno: Aluno) {
        viewModelScope.launch {
            dao.deleteAluno(aluno)
        }
    }

    // --- Escola Operations ---
    fun saveEscola(escola: Escola) {
        viewModelScope.launch {
            dao.insertEscola(escola)
        }
    }

    fun deleteEscola(escola: Escola) {
        viewModelScope.launch {
            dao.deleteEscola(escola)
        }
    }

    // --- Turma Operations ---
    fun saveTurma(turma: Turma) {
        viewModelScope.launch {
            dao.insertTurma(turma)
        }
    }

    fun deleteTurma(turma: Turma) {
        viewModelScope.launch {
            dao.deleteTurma(turma)
        }
    }

    // --- Responsavel Operations ---
    fun saveResponsavel(responsavel: Responsavel) {
        viewModelScope.launch {
            dao.insertResponsavel(responsavel)
        }
    }

    fun deleteResponsavel(responsavel: Responsavel) {
        viewModelScope.launch {
            dao.deleteResponsavel(responsavel)
        }
    }

    // --- MembroEquipe Operations ---
    fun saveMembroEquipe(membro: MembroEquipe) {
        viewModelScope.launch {
            dao.insertMembroEquipe(membro)
        }
    }

    fun deleteMembroEquipe(membro: MembroEquipe) {
        viewModelScope.launch {
            dao.deleteMembroEquipe(membro)
        }
    }
}